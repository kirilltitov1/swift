//
//  SettingsCell.swift
//  HW1
//
//  Created by Kirill Titov on 17/08/2019.
//  Copyright © 2019 Kirill Titov. All rights reserved.
//

import UIKit

class SettingsCell: UICollectionViewCell {
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var label: UILabel!
}
