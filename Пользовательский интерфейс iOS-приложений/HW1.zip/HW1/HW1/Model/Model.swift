//
//  Model.swift
//  HW1
//
//  Created by Kirill Titov on 15/08/2019.
//  Copyright © 2019 Kirill Titov. All rights reserved.
//

import UIKit


class Model {
    var User: String = "Титов Кирилл"
    var Groups: [String] = ["1", "2", "3", "4"]
}
