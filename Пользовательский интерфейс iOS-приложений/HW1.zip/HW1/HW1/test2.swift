//
//  test2.swift
//  HW1
//
//  Created by Kirill Titov on 11/08/2019.
//  Copyright © 2019 Kirill Titov. All rights reserved.
//

import Foundation

class test2: UIViewController {
    <#code#>
}
