//
//  Functions.swift
//  HW1
//
//  Created by Kirill Titov on 27/08/2019.
//  Copyright © 2019 Kirill Titov. All rights reserved.
//

import Foundation


public func arrayContains(needle: String, arrhaystack: [String]) -> Bool{
    return arrhaystack.contains(needle);
}
